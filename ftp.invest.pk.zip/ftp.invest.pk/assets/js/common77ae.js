function ajaxLogin() {    
    $('#sucMsgSpan').html('');
    $('#sucMsgDiv').hide();
    
    $('#errMsgSpan').html('');
    $('#errMsgDiv').hide();
    
    $('#btnLogin').hide();
    
    var datastring = $('form#loginForm').serialize();
    //datastring += '&id=' + id;
    console.log(datastring);
    
    $.ajax({
        type: 'POST',
        url: baseUrl + 'login-api',
        data: datastring,
        cache: false,
        success: function (response) {
            console.log(response);

            if (response.status) {
                $('#sucMsgSpan').html(response.msg);
                $('#sucMsgDiv').show();
                
                var redirectUrl = response.redirectUrl;
                
                setTimeout(function() { window.location = redirectUrl; }, 4000);
            } else {
                $('#errMsgSpan').html(response.msg);
                $('#errMsgDiv').show();
                $('#btnLogin').show();
            }
        } // success call back
    });
} // ajax login ends

function ajaxChangePassword() {    
    $('#sucMsgSpan').html('');
    $('#sucMsgDiv').hide();
    
    $('#errMsgSpan').html('');
    $('#errMsgDiv').hide();
    
    $('#btnChangePassword').hide();
    
    var datastring = $('form#loginForm').serialize();
    //datastring += '&id=' + id;
    console.log(datastring);
    
    $.ajax({
        type: 'POST',
        url: baseUrl + 'change-password-api',
        data: datastring,
        cache: false,
        success: function (response) {
            console.log(response);

            if (response.status) {
                $('#sucMsgSpan').html(response.msg);
                $('#sucMsgDiv').show();
                $('.password').val('');
                $('#btnChangePassword').show();
            } else {
                $('#errMsgSpan').html(response.msg);
                $('#errMsgDiv').show();
                $('#btnChangePassword').show();
            }
        } // success call back
    });
} // ajax login ends

function addToCart(id) {    
    $('.itemAlertMsg').html('');
    $('.itemMsgDiv').hide();
    
    console.log(id);
    var datastring = $('#itemForm_' + id).serialize();
    datastring += '&id=' + id;
    console.log(datastring);
    
    $.ajax({
        type: 'POST',
        url: baseUrl + 'addToCart',
        data: datastring,
        cache: false,
        success: function (response) {
            console.log(response);

            if (response.status) {
                //$("#contactForm").trigger('reset');
                $('#itemSucMsg').html(response.msg);
                $('#itemSucMsgDiv').show();

                setTimeout(function() { $('.itemAlertMsg').html(''); $('.itemMsgDiv').hide(); }, 10000);
            } else {
                $('#itemErrMsg').html(response.msg);
                $('#itemErrMsgDiv').show();
            }
        }
    });
} // add to cart ends

function loadCartPopup() {    
    $('#cartLength').html('');
    $('#cartTableBody').html('');
    
    var datastring = $('#cartModalForm').serialize();
    console.log(datastring);
    
    $.ajax({
        type: 'POST',
        url: baseUrl + 'loadCart',
        data: datastring,
        cache: false,
        success: function (response) {
            console.log(response);
            var cartTableBody = '';
            var cartLength = 0;
                
            if (response.status) {
                cartLength = (typeof response.cartItems.length != 'undefined' ? response.cartItems.length : 0);
                $('#cartLength').html(cartLength);
                
                if (cartLength > 0) {
                    $.each(response.cartItems, function(k, v) {
                        //console.log(k + ' ' + v);
                        cartTableBody += '<tr>\n';
                        cartTableBody += '  <td style="width: 150px;">\n';
                        cartTableBody += '      <div class="Cart whatsNewBox d-flex justify-content-center align-items-center">\n';
                        cartTableBody += '          <div class="">\n';
                        cartTableBody += '              <div class="">\n';
                        cartTableBody += '                  <a href="#">\n';
                        cartTableBody += '                      <img src="'+v.imageUrl+'" alt="'+v.name+'" title="'+v.name+'">\n';
                        cartTableBody += '                  </a>\n';
                        cartTableBody += '              </div>\n';
                        cartTableBody += '          </div>\n';
                        cartTableBody += '      </div>\n';
                        cartTableBody += '  </td>\n';
                        cartTableBody += '  <td>\n';
                        cartTableBody += '      <div class="productDetail d-flex align-items-center">\n';
                        cartTableBody += '          <div class="">\n';
                        cartTableBody += '              <p>'+v.name+'</p>\n';
                        cartTableBody += '              <p>Price: '+v.price+'</p>\n';
                        cartTableBody += '              <p>Quantity: '+v.qty+'</p>\n';
                        cartTableBody += '              <p>Sub Total: '+v.subtotal+'</p>\n';
                        cartTableBody += '          </div>\n';
                        cartTableBody += '      </div>\n';
                        cartTableBody += '  </td>\n';
                        cartTableBody += '</tr>';                        
                    });
                    
                    cartTableBody += '<tr>';
                    cartTableBody += '  <td>';
                    cartTableBody += '      <b>TOTAL</b>';
                    cartTableBody += '  </td>';
                    cartTableBody += '  <td class="text-right">';
                    cartTableBody += '      $' + response.cartTotal;
                    cartTableBody += '  </td>';
                    cartTableBody += '</tr>';
                }
                
                $('#cartTableBody').html(cartTableBody);
                //$('#itemSucMsgDiv').show();
            } else {
                //$('#itemErrMsg').html(response.msg);
               // $('#itemErrMsgDiv').show();
               console.log('Cart items not found');
            }
            $('#cartLength').html(cartLength);
        }
    });
} // load cart items ends

function updateCart(cartItemId) {    
    console.log(cartItemId);
    
    var datastring = $('#cartForm').serialize();
    console.log(datastring);
    
    $.ajax({
        type: 'POST',
        url: baseUrl + 'updateCart',
        data: datastring,
        cache: false,
        success: function (response) {
            console.log(response);
            
            if (response.status) {
                cartLength = (typeof response.cartItems.length != 'undefined' ? response.cartItems.length : 0);
                $('#itemCount').val(cartLength);
                
                if (cartLength > 0) {
                    $.each(response.cartItems, function(k, v) {
                        if (v.id == cartItemId) {
                            $('#subtotal[' + cartItemId + ']').val(v.subtotal);
                            $('#subtotal_' + cartItemId).html('$'+ v.subtotal);
                        }
                    });
                } // cart length
                
                var cartTotal = (typeof response.cartTotal != 'undefined' ? response.cartTotal : 0);
                $('#cartTotal').val(cartTotal);
                $('#tdCartTotal').html('$' + cartTotal);
                
                //$("#contactForm").trigger('reset');
                $('#itemSucMsg').html(response.msg);
                $('#itemSucMsgDiv').show();

                setTimeout(function() { $('.itemAlertMsg').html(''); $('.itemMsgDiv').hide(); }, 10000);
            } else {
                $('#itemErrMsg').html(response.msg);
                $('#itemErrMsgDiv').show();
            }
        }
    });
} // update cart ends

function removeCartItem(rowid, cartItemId) {    
    console.log(cartItemId);
    $('#itemRow_' + cartItemId).remove();
    
    var datastring = 'action=removeFromCart&rowid=' + rowid + '&csrf_name=' + $('#csrf_name').val();
    console.log(datastring);
        
    $.ajax({
        type: 'POST',
        url: baseUrl + 'removeFromCart',
        data: datastring,
        cache: false,
        success: function (response) {
            console.log(response);
            
            if (response.status) {
                cartLength = (typeof response.cartItems.length != 'undefined' ? response.cartItems.length : 0);
                $('#itemCount').val(cartLength);
                
                if (cartLength > 0) {
                    //$.each(response.cartItems, function(k, v) {
                    //    if (v.id == cartItemId) {
                    //        $('#subtotal[' + cartItemId + ']').val(v.subtotal);
                    //        $('#subtotal_' + cartItemId).html('$'+ v.subtotal);
                    //    }
                    //});
                } // cart length
                
                var cartTotal = (typeof response.cartTotal != 'undefined' ? response.cartTotal : 0);
                $('#cartTotal').val(cartTotal);
                $('#tdCartTotal').html('$' + cartTotal);
            } 
        }
    });
    //updateCart(cartItemId);
} // update cart ends

function handleContactForm() {
    // Get form values
    var name = $('#name').val().trim();
    var subject = $('#subject').val().trim();
    var email = $('#email').val().trim();
    var phone_no = $('#phone_no').val().trim();
    var message = $('#message').val().trim();
    
    // Email and Phone patterns
    var emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    var phonePattern = /^[0-9]{10,15}$/;

    // Field validation
    if (!name) {
        alert("Please enter your name.");
        $('#name').focus();
        return;  // Stop submission if validation fails
    }

    if (!subject) {
        alert("Please select a type of inquiry.");
        $('#subject').focus();
        return;  // Stop submission if validation fails
    }

    if (!email) {
        alert("Please enter your email address.");
        $('#email').focus();
        return;  // Stop submission if validation fails
    }

    if (!emailPattern.test(email)) {
        alert("Please enter a valid email address.");
        $('#email').focus();
        return;  // Stop submission if validation fails
    }

    if (!phone_no) {
        alert("Please enter your phone number.");
        $('#phone_no').focus();
        return;  // Stop submission if validation fails
    }

    if (!phonePattern.test(phone_no)) {
        alert("Please enter a valid phone number (10-15 digits).");
        $('#phone_no').focus();
        return;  // Stop submission if validation fails
    }

    if (!message) {
        alert("Please enter your message.");
        $('#message').focus();
        return;  // Stop submission if validation fails
    }

    // If all fields are valid, proceed with the AJAX request
    $.ajax({
        url: baseUrl + 'services/site/contactUs',
        type: 'POST',
        data: $('#contactForm').serialize() + '&action=submit',  // Add action parameter
        dataType: 'json',
        success: function(response) {
            if (response.status) {
                $('#sucMsg').text(response.msg);
                $('#sucMsgDiv').show();
                $('#errMsgDiv').hide();
                
                // Reset the form fields
                $('#contactForm').trigger("reset");
            } else {
                $('#errMsg').text(response.msg);
                $('#errMsgDiv').show();
                $('#sucMsgDiv').hide();
            }
        },
        error: function(xhr, status, error) {
            $('#errMsg').text("An error occurred. Please try again.");
            $('#errMsgDiv').show();
            $('#sucMsgDiv').hide();
        }
    });
}



function joinCourse(id) {    
    $('.itemAlertMsg').html('');
    $('.itemMsgDiv').hide();
    
    console.log(id);
    var datastring = $('#itemForm_' + id).serialize();
    datastring += '&id=' + id;
    console.log(datastring);
    
    $.ajax({
        type: 'POST',
        url: baseUrl + 'joinCourse',
        data: datastring,
        cache: false,
        success: function (response) {
            console.log(response);

            if (response.status) {
                //$("#contactForm").trigger('reset');
                $('#itemSucMsg').html(response.msg);
                $('#itemSucMsgDiv').show();

                setTimeout(function() { $('.itemAlertMsg').html(''); $('.itemMsgDiv').hide(); }, 10000);
            } else {
                $('#itemErrMsg').html(response.msg);
                $('#itemErrMsgDiv').show();
                
                if (typeof response.login !== 'undefined' && response.login == 0) {
                    setTimeout(function() { window.location.href = baseUrl + "login"; }, 3000);
                }
            }
        }
    });
} // join course ends

function courseSearch() {
    var courseSearchKw = $('#courseSearchKw').val();
    //var citySearchKw = $('#citySearchKw').val();
    //var chkCourseMode = $('#chkCourseMode:checked').val();
    var chkCourseMode = $('#chkCourseMode').val();
    var courseCategoryId = $('#course_category_id').val();

    courseSearchKw = $.trim(courseSearchKw);
    //citySearchKw = $.trim(citySearchKw);

    console.log(courseSearchKw);
    console.log(courseCategoryId);
    console.log(chkCourseMode);

    //if (courseSearchKw == '' && !chkCourseMode && courseCategoryId == '' && citySearchKw == '') { 
    if (courseSearchKw == '' && courseCategoryId == '' && chkCourseMode == '') { 
        console.log('type keyword first');
        return false;
    }
} // course search

function productSearch() {
    var productSearchKw = $('#productSearchKw').val();
    var productCategoryId = $('#product_category_id').val();

    productSearchKw = $.trim(productSearchKw);
    
    console.log(productSearchKw);
    console.log(productCategoryId);
    
    if (productSearchKw == '' && productCategoryId == '') { 
        console.log('type keyword first');
        return false;
    }
} // product search

var reloadPage = function () {
    //jQuery('#sessionTimeOut').modal();
    jQuery('#sessionTimeOut').modal({
                                        backdrop: 'static', 
                                        keyboard: false
                                    });
    
} 

function showSuggestions(fieldId) {
    if (typeof fieldVal == 'undefined' || fieldId == '') {
        fieldId = 'topSearchTxt'; // 'search-box';
    }
    
    var searchWord = $('#' + fieldId).val();
    searchWord = jQuery.trim(searchWord);
    
    if (searchWord.length < 2) {
        return;
    }
    
    var searchUrl = baseUrl + 'services/PkfinanceBeApi/getSymbolSuggestions';
    var dataString = 'search=' + searchWord + '&csrf_name=' + cstHash; // &call=ajax
        
    $.ajax({
        type: 'POST',
        url: searchUrl,
        data: dataString,
        beforeSend: function() {
            $('#search-box').css('background', '#FFF url(../img/icons/LoaderIcon.gif) no-repeat 165px');
        },
        success: function(data) {
            console.log(data);
            
            $('#sticker-sticky-wrapper .classy-nav-container').css('z-index', 0);
            
            $('#suggesstion-box').show();
            $('#suggesstion-box').html(data.sHtml);
            $('#' + fieldId).css('background', '#FFF');
        }
    });
} // show suggestions ends

function selectSuggestion(smb, nm) { // prodVal
    $('#' + fieldId).val(smb + ' - ' + nm);
    $('#' + fieldIdSymbol).val(smb);
    
    $('#suggesstion-box').hide();
    
    $('#sticker-sticky-wrapper .classy-nav-container').css('z-index', 100);
    $('#headerSearchBtn').trigger('click');
} // select suggestion ends

// download file model
function downloadFile(elem) {
    $('#downloadFileBtn').attr('href', $(elem).data('href'));
    $("#downloadModal").modal('show');
} // downlaod file ends 

function loadSymbols() {
    $('#symbolsSelect').select2({
        width: '100%', placeholder: "Select Symbol",
        allowClear: true, 
        // language: {searching: function() {return "Searching..."}},
        ajax: {
            url: baseUrl + 'services/site/getSymbols',
            dataType: 'json',
            data: function (params) {
                return {symbolKw: params.term, page: params.page || 1}
            },
            cache: true
        }
    });
} // load symbols 

function gotoStockPage(symbol) {
    if (!symbol) {
        return false;
    }
    
    window.location = baseUrl + 'symbol/stock/' + symbol;
} // go to stock page ends

$(document).ready(function() {
    loadSymbols(); // initialize on start 
});

function toggleStockChart(chartInterval) {
    console.log(chartInterval);
    $('.stockChartItem').hide();
    $('.stockChartItem-' + chartInterval).show();
} // toggle stock chart